# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import sys

def main():
    if len(sys.argv) != 3:
        print 'Usage: python extract_fails.py INPUT_DATA CLASSIFIER_RESULTS'
    
    input_file = sys.argv[1]
    classifier_results = sys.argv[2]

    output_file = 'fails/' + input_file.split('/')[-1]

    print 'Output file: {0}'.format(output_file)

    with open(input_file) as in_data, \
        open(classifier_results) as results, \
        open(output_file, 'w') as output:
        corpus = zip((line for line in in_data), (classif.strip() for classif in results))

        for line, val in corpus:
            if val == 'B':
                output.write(line)

if __name__ == '__main__':
    main()
