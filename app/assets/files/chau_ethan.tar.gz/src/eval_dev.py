# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import sys

def main():
    if len(sys.argv) != 2:
        print 'Usage: python eval_dev.py CLASSIFIER_RESULTS'
        exit(1)
    
    filename = sys.argv[1]
    correct = 0.0
    total = 0.0
    with open(filename) as file:
        for entry in file:
            total += 1
            # since data is dev, all 'correct' data is on the left
            if entry.strip() == 'A':
                correct += 1
    
    print 'Correct: {0}'.format(correct)
    print 'Total: {0}'.format(total)
    print 'Accuracy: {0}'.format((correct / total))

if __name__ == '__main__':
    main()