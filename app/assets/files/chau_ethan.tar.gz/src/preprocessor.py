# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import argparse

def length(filename):
    with open(filename) as file:
       file_length = sum(1 for line in file)
    print file_length

def partition(filename, train_size):
    train_name = filename + '.train'
    dev_name = filename + '.dev'
    
    print 'Writing train to {0}\n\tand dev to {1}'.format(train_name, dev_name)

    with open(filename) as in_file, \
        open(train_name, 'w') as train_file, \
        open(dev_name, 'w') as dev_file:
        i = 0
        for line in in_file:
            if i < train_size:
                train_file.write(line)
            else:
                dev_file.write(line)
            if i % 10000 == 0:
                print i
            i += 1

def split(filename, separator='\t'):
    clean_name = filename + '.clean'
    mangled_name = filename + '.mangled'

    print 'Writing clean to {0}\n\tand mangled to {1}'.format(clean_name, mangled_name)

    with open(filename) as in_file, \
        open(clean_name, 'w') as clean_file, \
        open(mangled_name, 'w') as mangled_file:
        for sentence in in_file:
            cleaned = sentence.strip()
            left, right = cleaned.split(separator)
            clean_file.write(left)
            clean_file.write('\n')
            mangled_file.write(right)
            mangled_file.write('\n')

def main():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    
    parser.add_argument('--filename', type=str, help='File to load.', 
        required=True)
    parser.add_argument('--length', action='store_true', help=(
        'Output length of file.'))
    parser.add_argument('--partition', action='store_true', help=(
        'Partition file into train and dev.'))
    parser.add_argument('--train-size', type=int, default=900000, help=(
        'Amount of data given to train set on partition.'))
    parser.add_argument('--split', action='store_true', help=(
        'Split left and right sentences into different files.'))
    parser.add_argument('--separator', type=str, help=(
        'Separator for splitting'))

    args = parser.parse_args()

    if args.length:
        length(args.filename)
    elif args.partition:
        partition(args.filename, args.train_size)
    elif args.split:
        if args.separator:
            split(args.filename, args.separator)
        else:
            split(args.filename)
    else:
        print 'No action specified.  Exiting...'


if __name__ == '__main__':
    main()
