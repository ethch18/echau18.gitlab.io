#### ARK Challenge, Spring 2018
Ethan Chau (echau18)

##### File Usage
###### `preprocessor.py`
Various preprocessing tools for the data:

* length - determines the length of a file; output is the same as that of running `wc -l`
* partition - partitions training data into train and dev/validate sections
* split - splits the two columns of the training data into "clean" and "mangled/corrupted"

Usage:
```
python2 preprocessor.py [-h] --filename FILENAME [--length] [--partition]
            [--train-size TRAIN_SIZE=900000] [--split]
            [--separator SEPARATOR='\t']
```
###### `classifier.py`
Determines which of the two sentences is more probable based on a clean model and an optional mangled model.  Writes 'A' for the left sentence and 'B' for the right, to the provided output file.

Usage:
```
python2 classifier.py [-h] --clean-model CLEAN_MODEL
            [--mangled-model MANGLED_MODEL=None] --test-file TEST_FILE
            --output-file OUTPUT_FILE
```
###### `eval_dev.py`
Evaluates classifier output for the dev set, for which the correct answer is always 'A'.

Usage:
```
python2 eval_dev.py CLASSIFIER_RESULTS
```
###### `extract_fails.py`
Extract incorrectly classified lines from input data.

Usage:
```
python2 extract_fails.py INPUT_DATA CLASSIFIER_RESULTS
```
###### `mangler.py`
Mangles sentences and outputs them to a file in the following format:

```
[original][\t][mangled][\n]
```

Usage:
```
python2 mangler.py [-h] --clean-data CLEAN_DATA
```
###### `diff.py`
Asserts that the clean and mangled sentences in a file are different.

Usage:
```
python2 diff.py DATA_FILE
```
