# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import sys

def main():
    if len(sys.argv) != 2:
        print 'Usage: python diff.py DATA_FILE'
        exit(1)
    
    data_file = sys.argv[1]

    with open(data_file) as data:
        i = 1
        status = True
        for line in data:
            left,right = line.strip().split('\t')
            if left == right:
                status = False
                print 'Line {0}: {1}\t{2}'.format(i, left, right)
            i += 1
        print 'Success: {0}'.format(status)
        
if __name__ == '__main__':
    main()
