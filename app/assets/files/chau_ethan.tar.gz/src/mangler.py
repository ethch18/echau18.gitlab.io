# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import argparse
import random
DROP_SUFF = set(['ly', 'ous', 'ose', 'ble', 'ic', 'ary', 'ive', 'ish'])
DROP_WORD = set(['the', 'a', 'an', 'by', 'at', 'for', 'from', 'of', 'on', 'in', 'to'])

def isUC(char):
    return ord(char) >= ord('A') and ord(char) <= ord('Z')

class Mangler:
    def __init__(self, in_file):
        """
        Parameters
        ----------
        in_file: str
            Name of file to generate vocabulary from.
        """
        self.propers = {}
        
        with open(in_file) as data:
            for line in data:
                tokens = line.strip().split(' ')
                # skip line[0] since it's the start of a sentence and could be anything
                for token in tokens[1:]:
                    first_char = token[0]
                    if isUC(first_char):
                        if first_char not in self.propers:
                            self.propers[first_char] = set()
                        self.propers[first_char].add(token)

    def mangle(self, sentence):
        """
        Parameters
        ----------
        sentence: list
            Sentence to mangle.

        Returns
        ----------
        Mangled version of sentence, in list form.
        """

        done = False

        for i in range(1, len(sentence), 1):
            token = sentence[i]
            first_char = token[0]

            # only want to proper-swap if there's another option
            if first_char in self.propers and len(self.propers[first_char]) > 1:
                # randomly select prop-noun to swap in
                new_proper = random.sample(self.propers[first_char], 1)[0]
                while new_proper == token:
                    new_proper = random.sample(self.propers[first_char], 1)[0]
                
                sentence[i] = new_proper
                done = True
                log = 'Prop: {0} -> {1}'.format(new_proper, sentence)
                break
            elif token[-3:] in DROP_SUFF or token[-2:] in DROP_SUFF or token in DROP_WORD:
                # delete a word
                del sentence[i]
                done = True
                log = 'Del {0}'.format(token)
                break
        
        if not done:
            if len(sentence) > 1:
                start_index = random.randrange(len(sentence) - 1)
                # flip coin, decide if want to alternate or tack
                if random.randint(0, 1) and not (len(set(sentence)) == 1):
                    # alternate/swap two words
                    while sentence[start_index] == sentence[start_index + 1]:
                        start_index = random.randrange(len(sentence) - 1)

                    sentence[start_index], sentence[start_index + 1] = sentence[start_index + 1], sentence[start_index]
                    log = 'Alt'
                else:
                    # tack on to end
                    end_char = sentence[start_index][-1]
                    sentence[start_index] = sentence[start_index][:-1]
                    sentence[start_index + 1] = end_char + sentence[start_index + 1]
                    if sentence[start_index] == '':
                        del sentence[start_index]
                    log = 'Tack'
            else:
                # word-internal manipulation
                if len(sentence[0]) > 1 and not (len(set(sentence[0])) == 1):
                    # character swap
                    only_word = sentence[0]
                    start_index = random.randrange(len(only_word) - 1)
                    while only_word[start_index] == only_word[start_index + 1]:
                        start_index = random.randrange(len(only_word) - 1)
                    new_word = only_word[:start_index] + only_word[start_index + 1] + only_word[start_index] + only_word[start_index + 2:]
                    sentence[0] = new_word
                    log = 'Twist -> {0}'.format(new_word)
                else:
                    # add a random character
                    new_char = chr(random.randrange(ord('a'), ord('z') + 1, 1))
                    sentence[0] += new_char
                    log = 'Append {0}'.format(new_char)
        
        return sentence, log


def write_mangled(clean_data):
    out_file = 'mangled/' + clean_data.split('/')[-1]
    log_file = out_file + '.log'
    mangler = Mangler(clean_data)

    print('Writing to {0}...'.format(out_file))
    print('Logging to {0}...'.format(log_file))
    i = 0
    with open(clean_data) as data, \
        open(out_file, 'w') as output, \
        open(log_file, 'w') as log:
        for line in data:
            if i % 1000 == 0:
                print i
            sentence = line.strip()
            tokens = sentence.split(' ')
            mangled_tokens, log_output = mangler.mangle(tokens)
            mangled_sentence = ' '.join(mangled_tokens)

            output.write('{0}\t{1}\n'.format(sentence, mangled_sentence))
            log.write('{0}\n'.format(log_output))

            if sentence == mangled_sentence:
                log.write('Sentence was not properly mangled:')
                log.write('\t{0}'.format(sentence))
            i += 1


def main():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    
    parser.add_argument('--clean-data', type=str, help=(
        'File containing strings to mangle.'), required=True)
    
    args = parser.parse_args()
    write_mangled(args.clean_data)

if __name__ == '__main__':
    main()
