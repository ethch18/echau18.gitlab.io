# Ethan Chau (echau18)
# ARK Challenge, Spring 2018
import argparse
import kenlm

def score(model_file, test_file, output_file, mangled_file=None):
    model = kenlm.LanguageModel(model_file)
    if mangled_file:
        print 'Using mangled model...'
        mangled_model = kenlm.LanguageModel(mangled_file)
    with open(test_file) as test_data, \
        open(output_file, 'w') as output:
        i = 0
        for line in test_data:
            if i % 1000 == 0:
                print i
            left, right = line.split('\t')
            left_score = model.score(left)
            right_score = model.score(right)

            if mangled_file:
                left_score -= mangled_model.score(left)
                right_score -= mangled_model.score(right)

            output.write('A' if left_score > right_score else 'B')
            output.write('\n')
            i += 1

def main():
    parser = argparse.ArgumentParser(
       formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    
    parser.add_argument('--clean-model', type=str, help=(
        'ARPA model trained on clean data.'), required=True)
    parser.add_argument('--mangled-model', type=str, help=(
        'ARPA model trained on dirty data.'), default=None)
    parser.add_argument('--test-file', type=str, help=(
        'File to evaluate.'), required=True)
    parser.add_argument('--output-file', type=str, help=(
        'File to output to.'), required=True)

    args = parser.parse_args()
    score(args.clean_model, args.test_file, args.output_file, args.mangled_model)
    

if __name__ == '__main__':
    main()
